function printmsg(message)
{
    console.log(message)
}

function welcome ()
{
    console.log("  ‘Welcome to my application. I am Saurabh Tripathi and a part of FunctionUp Uranium cohort.’")
}

module.exports.welcome=welcome;
module.exports.printmsg=printmsg;